rm -Rf /usr/share/tomcat/work/Catalina/localhost/~dit/org/apache/jsp/
